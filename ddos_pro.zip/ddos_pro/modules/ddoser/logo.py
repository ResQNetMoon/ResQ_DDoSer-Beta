import os
def showlogo():
	pass
	#os.system("chmod -R +x __pycache__/system_spender.elf")
	#os.system("./__pycache__/system_spender.elf")
