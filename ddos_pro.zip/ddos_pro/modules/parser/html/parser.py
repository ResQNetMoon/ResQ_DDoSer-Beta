from bs4 import BeautifulSoup as supe
import sys
from requests import get
W  = '\033[0m'  # white (normal)
R  = '\033[31m' # red
G  = '\033[32m' # green
O  = '\033[33m' # orange
B  = '\033[34m' # blue
P  = '\033[35m' # purple

print(G+"Starting..."+W)
data = get(sys.argv[1]).text
ss = supe(data, "html.parser")
ss.find(sys.argv[1], sys.argv[3])
