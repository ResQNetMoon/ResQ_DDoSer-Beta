import sys
import os
W  = '\033[0m'  # white (normal)
R  = '\033[31m' # red
G  = '\033[32m' # green
O  = '\033[33m' # orange
B  = '\033[34m' # blue
P  = '\033[35m' # purple
f = open("about.tail")
print(B+f.read()+W)
f.close()
while True:
	print(G+"Run command attack for usange attacks module"+W)
	comman = input(G+"Command: ")
	print(W+"", end='')
	command = comman.split(" ")
	del comman
	if command[0] == 'attack':
		try:
		 error = 0
		 type = command[1]
		 purprose = command[2]
		except IndexError:
			error = 1
		if error == 1:
			print(R+"Argument's error\nUsage attack: attack [type] [purprose]\n ex: attack ddos http://localhost/ \n" +W)
			error = 0
		else:
		 if type == 'ddos':
			 os.system("cd modules/ddoser && python3 doser.py "+purprose)
	if command[0] == 'parse_html':
		try:
			typess = 'id'
			attrs = command[1]
			when = command[3]
			if command[2] == '2':
				typess = 'class'
			os.system("cd modules/parser/html && python3 parser.py "+typess+" "+attrs+" "+when)
		except IndexError:
			print(R+"Error argument's\nUsage: parse_html [url example: http://google.ru/] [id(1) or class(2)] [type ] [who parse]")
			print(W+"", end='')
