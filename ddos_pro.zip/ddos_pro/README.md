# ddos_pro
this is a virus meterpreter injected on python script 
for unix systems,
don't use this file
of edit cotntent of function
def showlogo():
 pass
